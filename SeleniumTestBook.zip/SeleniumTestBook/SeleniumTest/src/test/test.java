package test;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.junit.Assert;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import com.csvreader.CsvReader;

public class test {
	private static WebDriver driver;

//	public static void main(String[] args) throws InterruptedException {
//		run(addBooks());
//    }
	
	public static void setUp() {
		
		System.setProperty("webdriver.chrome.driver","C:\\workspace\\code\\monitor\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://localhost:14208/");
        System.out.println("Page title is: " + driver.getTitle());
        login();
       
	}
	static void login() {
		driver.findElement(By.id("MemberLogin1_txtMName")).sendKeys("51aspx");
		driver.findElement(By.id("MemberLogin1_txtMPwd")).sendKeys("51aspx");
		driver.findElement(By.id("MemberLogin1_ImageButton1")).click();
		
	}
	@Test
	public void readCsv()throws IOException, InterruptedException{
		String filePath = "C:\\workspace\\data.csv";
		CsvReader reader = new CsvReader(filePath, ',', Charset.forName("GBK"));
		reader.readHeaders();//������ͷ
		 while (reader.readRecord()) {
			 String user=reader.get(0);
			 String psd=reader.get(1);
			 System.out.println("��ǰ�к� " + reader.get(0));
			 
			 addUser(user,psd);
		 }
	}
	
	public void addUser(String username,String password) throws InterruptedException, IOException{
		setUp();
		
		
		//String username="name13";
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/map[1]/area[2]")).click();
		Thread.sleep(1500);
		driver.switchTo().frame("mainframe");
		driver.findElement(By.id("btnAgree")).click();	//book name
		Thread.sleep(1000);
		driver.findElement(By.id("txtLoginName")).sendKeys(username);	//book ISBN
		driver.findElement(By.id("txtPwd")).sendKeys(password);	//book author
		
		driver.findElement(By.id("txtTName")).sendKeys(username);	//��ʵ����	
		driver.findElement(By.id("txtQuePwd")).sendKeys("123");	//��������

		driver.findElement(By.id("txtAnsPwd")).sendKeys("test");//������ʾ��
		driver.findElement(By.xpath("//*[@id=\"btnRegister\"]")).click();
		
		String image=driver.findElement(By.xpath("//*[@id=\"form1\"]/div[3]/table")).getAttribute("style");
		System.out.print(image);
		String name=driver.findElement(By.xpath("//*[@id=\"labMName\"]")).getText();
		System.out.print(name);
		assert name.contains(username);
		
		Thread.sleep(2000);
		driver.quit();
	}
	
	@Test
	public void addCar() throws InterruptedException {
		setUp();
		Thread.sleep(1500);
		
		driver.findElement(By.xpath("/html/body/map[1]/area[1]")).click();
		driver.switchTo().frame("mainframe");
		driver.findElement(By.xpath("//*[@id=\"gvGoodsInfo\"]/tbody/tr[2]/td[4]/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("btnShop")).click();
		
		String m=driver.findElement(By.xpath("//*[@id=\"labMoney\"]")).getText();
		System.out.print(m);
		int i = Integer.parseInt( m ); 
		if(i != 0 ) {
			Assert.assertEquals(1,1);
		}
		else {
			Assert.assertEquals(2,1);
		}
		driver.close();
	}
	
	@Test
	public void searchGoods() throws InterruptedException {
		setUp();
		Thread.sleep(1500);
		
		driver.findElement(By.xpath("/html/body/map[1]/area[1]")).click();
		driver.switchTo().frame("mainframe");
		driver.findElement(By.id("txtKey")).sendKeys("15");
		Thread.sleep(1000);
		driver.findElement(By.id("btnSel")).click();
		
		String m=driver.findElement(By.xpath("//*[@id='gvGoodsInfo']/tbody/tr[2]/td[1]")).getText();
		System.out.print(m);
		
		assert m.contains("�·�");
		driver.close();
	}
	
	public void tearDown() {
		
		driver.close();
	}
}
